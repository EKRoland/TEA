mod besta;
mod config;
use config::CONFIG;
use crate::config::cfg;
use std::env;
use std::time::Instant;


/// To use:    ./target/release/besta besta n m



fn main() {
    let args: Vec<String> = env::args().skip(1).collect(); // skip program name

    if args.is_empty() {
        eprintln!("Usage: besta <n> <m>");
        return;
    }

    match args[0].as_str() {
        

        "besta" => {//sequentielle sur 1 proc
            if args.len() != 3 {
                eprintln!("Usage: besta <n> <m>");
                return;
            }
            let n: usize = args[1].parse().expect("Invalid number for n");
            let m: usize = args[2].parse().expect("Invalid number for m");
            let w=m+2;

            CONFIG.set(config::Config {
                n,
                m,
                w
            }).expect("CONFIG already initialized");
            
                
            
            let start_time = Instant::now();
            let mut best_cells = besta::new_cells();
            let mut current = ((n.div_ceil(2)) as isize , 1isize, 1u8);
            let mut m_up_down=((n.div_ceil(2)) as u8,(n.div_ceil(2))as u8);
            let mut cells = besta::new_cells();
            let mut h = 1u16;
            let hi = 1u16;
            let mut best_h=0u16;
            let mut best_out=(0isize,0isize,0u8);

            besta::trajectory( &mut current, &mut m_up_down, &mut cells, &mut h, hi, &mut best_h, &mut best_out, &mut best_cells);

            println!("Out position {:?}", best_out);
            println!("Out Color Configuration");
            besta::print_cells_raw(&best_cells, cfg().n + cfg().n.div_ceil(2) + 1, cfg().m +2);

            println!("Escaping Time {}", best_h-1); 

            //From the output configuration, by reversing the ant's direction and flipping the color of the cell through which the ant exited the grid, one can compute the escape time and recover the starting configuration.         
        }


        _ => {
            eprintln!("Unknown command: {}", args[0]);
        }
    }
}

