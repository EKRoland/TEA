
///une seule entrée
//utilisation de cells, 
//n et m fixé passer en parametre, taille de la grille en fonction de m et n
use std::time::Instant;
use crate::config::cfg;


/// Représente une cellule de la grille
#[repr(C)]
#[derive(Clone, Copy, Debug, Default)]
pub struct Cell {
    pub visits: u16,      // temps de visite
    pub last_turn: u8,    // 0 = left, 1 = right
    pub m_up_down:(u8,u8),

}

//new cell last turn à 1 mais sentinelle à 2

#[inline(always)]
pub fn new_cells() -> Box<[Cell]> {
    let rows = cfg().n + cfg().n.div_ceil(2) + 1;
    let cols = cfg().m + 2;

    let mut cells = vec![Cell::default(); rows * cols];

    for row in 0..rows {
        for col in 0..cols {
            let idx = row * cols + col;

            let is_border =
                row == 0 || row + 1 == rows ||
                col == 0 || col + 1 == cols;

            cells[idx].last_turn = if is_border { 2 } else { 1 };
        }
    }

    cells.into_boxed_slice()
}


pub fn print_cells_raw(cells: &[Cell], rows: usize, cols: usize) {
    for row in 1..rows-1 {
        for col in 1..cols-1 {
            let idx = row * cols + col;
            if cells[idx].visits==0{ 
                print!(" * ", );

            } else {
            print!("{:2} ", cells[idx].last_turn);
            }
        }
        println!();
    }
}





/// Calcul du successeur selon la direction et le turn
#[inline(always)]
fn successor((r, c, dir): (isize, isize, u8), turn: u8) -> (isize, isize, u8) {
    const DELTAS: [(isize, isize); 4] = [(-1, 0), (0, 1), (1, 0), (0, -1)];
    // turn=0 => Left => +3 ; turn=1 => Right => +1
    let new_dir = (dir + 1 + 2 * (turn ^ 1)) & 3;
    let (dr, dc) = DELTAS[new_dir as usize];
    (r + dr, c + dc, new_dir)
}

/// Cellule précédente selon la direction
#[inline(always)]
fn previous_cell((r, c, dir): (isize, isize, u8)) -> (isize, isize) {
    const DELTAS: [(isize, isize); 4] = [(-1, 0), (0, 1), (1, 0), (0, -1)];
    let (dr, dc) = DELTAS[dir as usize];
    (r - dr, c - dc)
}

/// Direction précédente
#[inline(always)]
fn previous_dir(dir_next: u8, turn: u8) -> u8 {
    (dir_next + 1 + 2 * turn) & 3
}

#[inline(always)]
pub fn trajectory(
    current: &mut (isize, isize, u8),
    m_up_down: &mut (u8, u8),
    cells: &mut [Cell],
    h: &mut u16,
    hi: u16,
    best: &mut u16,
    best_out: &mut (isize, isize, u8),
    best_cells: &mut [Cell],
) {
    let max_height = cfg().n as u8;
    let width = cfg().w as isize;

    'outer: loop {
        // ================= FORWARD =================
        loop {
            let (r, c, _) = *current;
            let idx = (r * width + c) as usize;
            let cell = &mut cells[idx];

            if cell.visits == 0 {
                // cellule sentinelle
                if cell.last_turn == 2 {
                    break;
                }

                let mut up = m_up_down.0;
                let mut down = m_up_down.1;
                let r_u8 = r as u8;

                if r_u8 < up {
                    up = r_u8;
                } else if r_u8 > down {
                    down = r_u8;
                }

                if down - up >= max_height {
                    break;
                }

                *m_up_down = (up, down);
                cell.visits = *h;
                cell.m_up_down = (up, down);
            }

            let turn = cell.last_turn ^ 1;
            let next = successor(*current, turn);

            cell.last_turn ^= 1;
            *current = next;
            *h += 1;
        }

        // ================= BEST =================
        if *h > *best {
            *best = *h;
            *best_out = *current;
            best_cells.clone_from_slice(cells);
        }

        // ================= BACKWARD =================
        loop {
            let (pr, pc) = previous_cell(*current);
            let idx_p = (pr * width + pc) as usize;
            let prev_cell = &mut cells[idx_p];

            
            let turn = prev_cell.last_turn;
            let prev_dir = previous_dir(current.2, turn);

            *current = (pr, pc, prev_dir);
            *h -= 1;

            if *h == prev_cell.visits {
                *m_up_down = prev_cell.m_up_down;

                if turn == 1 {
                    prev_cell.visits = 0;
                    prev_cell.last_turn = 0;

                    if *h <= hi {
                        break 'outer;
                    }
                } else {
                    break;
                }
            }
            prev_cell.last_turn ^= 1;
        }
    }
}




// Trajectory can be used in a parallel.


#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::CONFIG;

    fn init_cfg() {
        let _ = CONFIG.set(crate::config::Config {
            n: 6,
            m: 6,
            w: 6+2,
        });
    }

    
    #[test]
    fn test_trajectories(){
        init_cfg();

        let n = cfg().n as u8;
        let start_time = Instant::now();
        let mut best_cells = new_cells();
        let mut current = ((n.div_ceil(2)) as isize , 1isize, 1u8);
        let mut m_up_down=((n.div_ceil(2)),(n.div_ceil(2)));
        let mut cells = new_cells();
        let mut h = 1u16;
        let hi = 1u16;
        let mut best_h=0u16;
        let mut best_out=(0isize,0isize,0u8);

        trajectory( &mut current, &mut m_up_down, &mut cells, &mut h, hi, &mut best_h, &mut best_out, &mut best_cells);
    
        
        //println!("Time {}s",start_time.elapsed().as_secs_f32());
        
        println!("Out position {:?}", best_out);
        println!("Out Color Configuration");
        print_cells_raw(&best_cells, cfg().n + cfg().n.div_ceil(2) + 1, cfg().m +2);

        println!("Escaping Time {}", best_h-1); 

        //From the output configuration, by reversing the ant's direction and flipping the color of the cell through which the ant exited the grid, one can compute the escape time and recover the starting configuration.
        
        
    }


}



