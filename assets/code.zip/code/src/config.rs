use once_cell::sync::OnceCell;

#[derive(Debug)]
pub struct Config {
    pub n: usize,
    pub m: usize,
    pub w: usize, // W = m + 2
}

pub static CONFIG: OnceCell<Config> = OnceCell::new();

#[inline(always)]
pub fn cfg() -> &'static Config {
    CONFIG.get().expect("CONFIG not initialized")
}
